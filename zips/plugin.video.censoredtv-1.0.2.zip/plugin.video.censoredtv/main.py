# -*- coding: utf-8 -*-
"""
    Copyright (C) 2021 tracey-fans (plugin.video.censoredtv)

    SPDX-License-Identifier: MIT
    See LICENSES/MIT.md for more information.
"""
from __future__ import absolute_import, division, unicode_literals

import sys

from resources.lib.run_addon import run

run(sys.argv)
